var script = document.createElement('script');
script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js';


document.getElementById('next_line').innerHTML = '<span class="txt1" >\
Forgot\
</span>\
<a class="txt2" href="/reset_pro_password">\
Username / Password?\
</a>'