$(document).ready(function(){

$("#id_meet1_time").attr("type",'time');
$("#id_meet2_time").attr("type",'time');
$("#id_meet3_time").attr("type",'time');

});