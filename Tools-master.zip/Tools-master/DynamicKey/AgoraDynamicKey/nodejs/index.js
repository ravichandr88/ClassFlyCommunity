module.exports = {
  RtcTokenBuilder: require('./src/RtcTokenBuilder').RtcTokenBuilder,
  RtcRole: require('./src/RtcTokenBuilder').Role,
  RtmTokenBuilder: require('./src/RtmTokenBuilder').RtmTokenBuilder,
  RtmRole: require('./src/RtmTokenBuilder').Role
}